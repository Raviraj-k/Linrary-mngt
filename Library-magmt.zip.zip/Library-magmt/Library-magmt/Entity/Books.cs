﻿using Newtonsoft.Json;

namespace Library_magmt.Entity
{
        public class Books : BaseEntity
        {
            [JsonProperty(PropertyName = "uId", NullValueHandling = NullValueHandling.Ignore)]
            public string UId { get; set; }

            [JsonProperty(PropertyName = "bookId", NullValueHandling = NullValueHandling.Ignore)]
            public string BookId { get; set; }

            [JsonProperty(PropertyName = "bookName", NullValueHandling = NullValueHandling.Ignore)]
            public string BookName { get; set; }

            [JsonProperty(PropertyName = "bookAuthor", NullValueHandling = NullValueHandling.Ignore)]
            public string BookAuthor { get; set; }

            [JsonProperty(PropertyName = "bookDomain", NullValueHandling = NullValueHandling.Ignore)]
            public string BookDomain { get; set; }
        }
    
}
