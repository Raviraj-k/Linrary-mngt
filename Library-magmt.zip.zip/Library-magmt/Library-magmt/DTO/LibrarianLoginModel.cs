﻿using Newtonsoft.Json;

namespace Library_magmt.DTO
{
    public class LibrarianLoginModel
    {
        [JsonProperty(PropertyName = "uId", NullValueHandling = NullValueHandling.Ignore)]
        public string UId { get; set; }

        [JsonProperty(PropertyName = "instituteId", NullValueHandling = NullValueHandling.Ignore)]
        public string InstituteId { get; set; }

        [JsonProperty(PropertyName = "password", NullValueHandling = NullValueHandling.Ignore)]
        public string Password { get; set; }
    }
}
