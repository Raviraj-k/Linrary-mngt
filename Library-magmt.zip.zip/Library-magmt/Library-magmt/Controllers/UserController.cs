﻿using Library_magmt.DTO;
using Library_magmt.Entity;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Azure.Cosmos;
using System.ComponentModel;
using System.Threading.Tasks;
using Container = Microsoft.Azure.Cosmos.Container;

namespace Library_magmt.Controllers
{
    [Route("api/[controller]/[action]")]
    [ApiController]
    public class UserController : ControllerBase
    {
        private Container GetContainer()
        {
            string URI = Environment.GetEnvironmentVariable("cosmos-url");
            string PrimaryKey = Environment.GetEnvironmentVariable("auth-token");
            string DatabaseName = Environment.GetEnvironmentVariable("database-name");
            string ContainerName = Environment.GetEnvironmentVariable("container-name");

            CosmosClient cosmosClient = new CosmosClient(URI, PrimaryKey);
            Database database = cosmosClient.GetDatabase(DatabaseName);
            Container container = database.GetContainer(ContainerName);
            return container;
        }
        public readonly Container _container;
        public UserController()
        {
            _container = GetContainer();
        }

        //Student Sign-Up
        [HttpPost]
        public async Task<IActionResult>StudentSignUp(StudentSignupModel studentSignupModel)
        {
            try
            {
                Students student = new Students();

                student.FirstName = studentSignupModel.FirstName;
                student.LastName = studentSignupModel.LastName;
                student.RollNo = studentSignupModel.RollNo;
                student.UserName = studentSignupModel.UserName;
                student.Password = studentSignupModel.Password;

                student.Id = Guid.NewGuid().ToString();
                student.UId = student.Id;
                student.DocumentType = "student";

                student.CreatedOn = DateTime.Now;
                student.CreatedByName = "";
                student.CreatedBy = "";

                student.UpdatedOn = DateTime.Now;
                student.UpdatedByName = "";
                student.UpdatedBy = "";

                student.Version = 1;
                student.Active = true;
                student.Archieved = false;

                Students response = await _container.CreateItemAsync(student);

                StudentSignupModel model = new StudentSignupModel();
                
                model.UId = response.UId;
                model.FirstName = response.FirstName;
                model.LastName = response.LastName;
                model.RollNo = response.RollNo;
                model.UserName = response.UserName;
                model.Password = response.Password;

                return Ok(model);
            }
            catch
            {
                return BadRequest("Sign-Up Failed");
            }
        }

        //Student Login Check
        [HttpGet]
        public IActionResult StudentLogin(string userName , string password)
        {
            try
            {
                Students student = _container.GetItemLinqQueryable<Students>(true)
                    .Where(b => b.DocumentType == "student" && b.UserName == userName && b.Password == password)
                    .AsEnumerable().FirstOrDefault();

                var studentLoginModel = new StudentLoginModel();
                studentLoginModel.UId = student.UId;
                studentLoginModel.UserName = student.UserName;
                studentLoginModel.FirstName = student.FirstName;
                studentLoginModel.LastName = student.LastName; 
                studentLoginModel.RollNo = student.RollNo;

                return Ok(studentLoginModel);
            }
            catch
            {
                return BadRequest("Login Failed");
            }
        }

        //Librarian Sign-up
        [HttpPost]
        public async Task<IActionResult> LibraianSignUp(LibrarianSignupModel librarianSignupModel)
        {
            try
            {
                Librarian librarian = new Librarian();

                librarian.InstituteId = librarianSignupModel.InstituteId;
                librarian.AccessNo = librarianSignupModel.AccessNo;
                librarian.Password = librarianSignupModel.Password;

                librarian.Id = Guid.NewGuid().ToString();
                librarian.UId = librarian.Id;
                librarian.DocumentType = "librarian";

                Librarian response = await _container.CreateItemAsync(librarian);

                LibrarianSignupModel model = new LibrarianSignupModel();
                model.UId = response.UId;
                model.InstituteId = response.InstituteId;
                model.AccessNo = response.AccessNo;
                model.Password = response.Password;

                return Ok(model);
            }
            catch
            {
                return BadRequest();
            }
        }
        //Librarian Login Check
        [HttpGet]
        public IActionResult LibrarianLogin(string instituteId , string password)
        {
            try
            {
                Librarian lb = _container.GetItemLinqQueryable<Librarian>(true)
                    .Where(b=>b.DocumentType=="librarian" && b.InstituteId == instituteId && b.Password == password)
                    .AsEnumerable().FirstOrDefault();

                var model = new LibrarianLoginModel();
                model.UId = lb.UId;
                model.InstituteId=lb.InstituteId;
                return Ok(model);
            }
            catch
            {
                return BadRequest();
            }
        }
    }

}
