﻿using Library_magmt.DTO;
using Library_magmt.Entity;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Azure.Cosmos;

namespace Library_magmt.Controllers
{
    [Route("api/[controller]/[action]")]
    [ApiController]
    public class BookController : ControllerBase
    {
        private Container GetContainer()
        {
            string URI = Environment.GetEnvironmentVariable("cosmos-url");
            string PrimaryKey = Environment.GetEnvironmentVariable("auth-token");
            string DatabaseName = Environment.GetEnvironmentVariable("database-name");
            string ContainerName = Environment.GetEnvironmentVariable("container-name");

            CosmosClient cosmosClient = new CosmosClient(URI, PrimaryKey);
            Database database = cosmosClient.GetDatabase(DatabaseName);
            Container container = database.GetContainer(ContainerName);
            return container;
        }
        public readonly Container _container;
        public BookController()
        {
            _container = GetContainer();
        }

        //Add Books 
        [HttpPost]
        public async Task<IActionResult> AddBook(BookDetailsModel bookDetailsModel)
        {
            try
            {
                Books booksEntity = new Books();

                booksEntity.BookId = bookDetailsModel.BookId;
                booksEntity.BookName = bookDetailsModel.BookName;
                booksEntity.BookAuthor = bookDetailsModel.BookAuthor;
                booksEntity.BookDomain = bookDetailsModel.BookDomain;

                booksEntity.Id = Guid.NewGuid().ToString();
                booksEntity.UId = booksEntity.Id;
                booksEntity.DocumentType = "book";

                booksEntity.Version = 1;
                booksEntity.Active = true;
                booksEntity.Archieved = false;

                Books response = await _container.CreateItemAsync(booksEntity);

                BookDetailsModel model = new BookDetailsModel();
                model.UId = response.UId;
                model.BookId = response.BookId;
                model.BookName = response.BookName;
                model.BookAuthor = response.BookAuthor;
                model.BookDomain = response.BookDomain;

                return Ok(model);
            }
            catch
            {
                return BadRequest();
            }
        }


        //Get Single Book
        [HttpGet]
        public IActionResult GetBook(string bookName, string bookId)
        {
            try
            {
                Books books = _container.GetItemLinqQueryable<Books>(true)
                    .Where(b => b.DocumentType == "book" && b.BookName == bookName || b.BookId == bookId)
                    .AsEnumerable().FirstOrDefault();

                var model = new BookDetailsModel();
                model.UId = books.UId;
                model.BookId = books.BookId;
                model.BookName = books.BookName;
                model.BookAuthor = books.BookAuthor;
                model.BookDomain = books.BookDomain;

                return Ok(model);
            }
            catch
            {
                return BadRequest();
            }
        }
        //Get Available Books
        [HttpGet]
        public IActionResult AvailableBooks()
        {
            try
            {
                var booksList = _container.GetItemLinqQueryable<Books>(true)
                    .Where(b => b.DocumentType == "book" && b.Active == true && b.Archieved == false)
                    .AsEnumerable().ToList();
                List<BookDetailsModel> bookDetails = new List<BookDetailsModel>();
                foreach (var book in booksList)
                {
                    BookDetailsModel model = new BookDetailsModel();
                    model.UId = book.UId;
                    model.BookId = book.BookId;
                    model.BookName = book.BookName;
                    model.BookAuthor = book.BookAuthor;
                    model.BookDomain = book.BookDomain;

                    bookDetails.Add(model);
                }
                return Ok(bookDetails);
            }
            catch
            {
                return BadRequest();
            }
        }

        //Get Not Available Books
        [HttpGet]
        public IActionResult NotAvailableBooks()
        {
            try
            {
                var bookList = _container.GetItemLinqQueryable<Books>(true)
                    .Where(b => b.DocumentType == "book" && b.Archieved == true && b.Active == true)
                    .AsEnumerable().ToList();
                List<BookDetailsModel> bookDetails = new List<BookDetailsModel>();
                foreach (var book in bookList)
                {
                    BookDetailsModel model = new BookDetailsModel();
                    model.UId = book.UId;
                    model.BookId = book.BookId;
                    model.BookName = book.BookName;
                    model.BookAuthor = book.BookAuthor;
                    model.BookDomain = book.BookDomain;

                    bookDetails.Add(model);
                }

                return Ok();
            }
            catch
            {
                return BadRequest();
            }
        }

        //Update Book Details
        [HttpPut]
        public async Task<IActionResult> UpdateBookDetails(BookDetailsModel bookDetailsModel)
        {
            try
            {
                var existingbook = _container.GetItemLinqQueryable<Books>(true)
                    .Where(b => b.UId == bookDetailsModel.UId && b.DocumentType == "book" && b.Active == true && b.Archieved == false)
                    .AsEnumerable().FirstOrDefault();
                existingbook.Archieved = true;
                await _container.ReplaceItemAsync(existingbook, existingbook.Id);

                existingbook.Id = Guid.NewGuid().ToString();
                existingbook.UpdatedBy = "";
                existingbook.UpdatedByName = "";
                existingbook.UpdatedOn = DateTime.Now;
                existingbook.Version = existingbook.Version + 1;
                existingbook.Active = true;
                existingbook.Archieved = false;

                existingbook.BookId = bookDetailsModel.BookId;
                existingbook.BookName = bookDetailsModel.BookName;
                existingbook.BookAuthor = bookDetailsModel.BookAuthor;
                existingbook.BookDomain = bookDetailsModel.BookDomain;

                existingbook = await _container.CreateItemAsync(existingbook);

                BookDetailsModel model = new BookDetailsModel();
                model.UId = existingbook.UId;
                model.BookId = existingbook.BookId;
                model.BookName = existingbook.BookName;
                model.BookAuthor = existingbook.BookAuthor;
                model.BookDomain = existingbook.BookDomain;

                return Ok(model);
            }
            catch
            {
                return BadRequest();
            }
        }

        //Delete Book
        [HttpDelete]
        public async Task<IActionResult> DeleteBook(string bookId)
        {
            try
            {
                var book = _container.GetItemLinqQueryable<Books>(true)
                    .Where(b => b.BookId == bookId && b.DocumentType == "book" && b.Archieved == false && b.Active == true)
                    .AsEnumerable().FirstOrDefault();
                book.Active = false;
                await _container.ReplaceItemAsync(book, book.Id);
                return Ok(true);
            }
            catch
            {
                return BadRequest();
            }
        }

    }
}



/*
 feature :

1-  user : [ I can be able to login and singup ] 
      steps : 1 students must able to singup ( add student )
      steps : 2 Stundets must be able to log in ( request : username and pass .... ) return (uid):

need : student (dtype)   - CRUD
       librarian      - CRUD  

Deadline : Tomarrow (3 Jan ) 


2 - Book  
Features : 

1- Add Book , Delete , Update , Issue book , return book , Request (xyz) 
2 -  search by book-name , author , subject (get)


librarian : 
show books in library 
show borrowed books 
show total books 

Need : Book CRUD

 */